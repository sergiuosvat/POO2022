public class Person extends Supermarket{
    public int id;
    public String name;

    Person(int id, String name)
    {
        this.id = id;
        this.name = name;
    }
}
