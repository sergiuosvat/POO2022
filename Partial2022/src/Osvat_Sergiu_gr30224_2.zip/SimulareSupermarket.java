public class SimulareSupermarket{
    Supermarket supermarket = new Supermarket();
    Angajat a1 = new Angajat(1,"Ana");
    Angajat a2 = new Angajat(2, "Cristian");
    Client c1 = new Client(123, "Ionut");
    Client c2 = new Client(567, "George");
    Client c3 = new Client(789, "");
    Client c4 = new Client(0,"");
    ClientFidel cf1 = new ClientFidel(4, "Petru", a1);
    Produs p1 = new Produs("abc", 5, 2);
    Produs p2 = new Produs("dfg", 6,1);


}
